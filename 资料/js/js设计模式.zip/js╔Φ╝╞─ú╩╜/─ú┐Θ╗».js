const obj = (function () {
  var count = 0
  return {
    a() {
      return count++
    },
    b() {
      return count--
    },
  }
})()
