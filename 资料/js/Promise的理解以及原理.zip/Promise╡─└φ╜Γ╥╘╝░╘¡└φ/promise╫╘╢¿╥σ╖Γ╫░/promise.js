// 声明构造函数
function Promise(executor) {
  // 添加属性
  // this['[[promiseState]]'] = 'pending'
  this.promiseState = 'pending'
  this.promiseResult = null
  this.callbacks = []
  // 保存实例对象的this值
  const self = this
  // console.log(executor)
  // resolve 函数
  function resolve (data) {
    // 判断状态 因为状态只能修改一次  只有成功或者失败
    if (self.promiseState !== 'pending') return
    // console.log(this)
    // 1.修改对象的状态(promiseState)
    self.promiseState = 'fulfilled'
    // 2.设置对象结果值(promiseResult)
    self.promiseResult = data
    // 调用成功的回调函数 ？？？
    // console.log(self)
    // if (self.callbacks.length > 0) {
    // self.callback.onResolved(self.promiseResult)
    setTimeout(() => {  // 当改变完状态之后 这个回调函数执行就必须进队列 必须异步执行 不能立即执行
      self.callbacks.forEach((n) => n.onResolved(self.promiseResult))
      // }
    })
  }
  // reject 函数
  function reject(data) {
    // 判断状态 因为状态只能修改一次 只有成功或者失败
    if (self.promiseState !== 'pending') return
    // 1.修改对象的状态(promiseState)
    self.promiseState = 'rejected'
    // 2.设置对象结果值(promiseResult)
    self.promiseResult = data
    // if (self.callbacks.onRejectd) {
    //   self.callback.onRejectd(self.promiseResult)
    // }
    // if (self.callbacks.length > 0) {
    //  调用成功的回调函数 
    setTimeout(() => {  // 当改变完状态之后 这个回调函数执行就必须进队列 必须异步执行 不能立即执行
      self.callbacks.forEach((n) => n.onRejectd(self.promiseResult))
    })
    // }
  }

  // executor 执行器函数在内部是同步调用的
  try {
    // console.log(1111111);
    executor(resolve, reject)
  } catch (e) {
    // 修改promise 对象状态修改为[失败]
    // console.log(e);
    reject(e)
  }
}
// 添加 then 方法 如果封装为类 前面的加static 它不是实例对象 它属于类
Promise.prototype.then = function (onResolved, onRejectd) {
  const self = this
  // 判断回调函数
  if (typeof onRejectd !== 'function') {
    //异常穿透
    onRejectd = (resaon) => {
      throw resaon
    }
  }
  if (typeof onResolved !== 'function') {
    onResolved = (resaon) => resaon
  }
  // console.log(onResolved, onRejectd)
  // console.log(this.promiseState)
  // 这里是链式调用的时候 result拿到的是一个promise
  return new Promise((resolve, reject) => {
    // 封装函数
    function callback(type) {
      try {
        // 获取回调函数的执行结果
        const result = type(self.promiseResult)
        // console.log(result)
        // 判断
        if (result instanceof Promise) {
          result.then(
            (v) => {
              resolve(v)
            },
            (r) => {
              console.log(r)
              reject(r)
            }
          )
        } else {
          // 结果 对象状态为成功
          resolve(result)
        }
      } catch (e) {
        reject(e)
      }
    }
    // 调用回调函数
    try {
      if (this.promiseState === 'fulfilled') {
        setTimeout(() => { 
          callback(onResolved)
        })
      }
      if (this.promiseState === 'rejected') {
        setTimeout(() => { 
          callback(onRejectd)
        })
        
      }
      // console.log(this.promiseState)
      // 判断pending状态 异步处理的方法 防止加入异步定时器导致代码不执行
      // 只有异步的操作 状态才是pending
      if (this.promiseState === 'pending') {
        console.log('thenpending', 11111)
        // onRejectd(this.promiseResult)
        // 保存回调函数
        this.callbacks.push({
          onResolved: function () {
            callback(onResolved)
          },
          onRejectd: function () {
            callback(onRejectd)
          },
        })
      }
    } catch (e) {
      reject(e)
    }
  })
}
// 添加 catch 方法
Promise.prototype.catch = function (onRejectd) {
  // console.log(onRejectd)
  return this.then(undefined, onRejectd)
}
// 添加 resolve 方法
Promise.resolve = function (value) {
  // console.log(value)
  // 返回promise对象
  return new Promise((resolve, reject) => {
    if (value instanceof Promise) {
      value.then(
        (v) => {
          resolve(v)
        },
        (r) => {
          console.log(r)
          reject(r)
        }
      )
    } else {
      // 状态设置为成功
      resolve(value)
    }
  })
}
// 添加 reject 方法
Promise.reject = function (reason) { 
  return new Promise((resolve, reject) => { 
    reject(reason)
  })
}
// 添加 all 方法 all有一个失败就返会失败
Promise.all = function (promises) {
  // 返回的结果是Promise对象
  let count = 0
  let arr = [] // 存放成功结果的数组
  return new Promise((resolve, reject) => { 
    // promises.map
    for (let index = 0; index < promises.length; index++) {
      // const element = promises[index]
      // console.log(element)
      // 得知对象的状态是成功的
      // 每一个promise对象都成功 才能往下走
      promises[index].then(v => { 
        // resolve
        count++
        // 将当前promise对象成功的结果 存入倒数组中
        // arr.push(v) 不推荐 细节无法实现 结果的循序可能发生改变
        arr[index] = v
        if (count === promises.length) {
          // 修改状态
          resolve(arr)
        }
      }, r => { 
        reject(r)
      })
    }
  })
}
// 添加 race 方法
Promise.race = function (promises) {
  return new Promise((resolve, reject) => { 
    for (let index = 0; index < promises.length; index++) {
      promises[index].then(
        (v) => {
          // 不管异步 谁先改变状态 就把谁返回回去
          // 修改返回对象的状态为 [成功]
         resolve(v)
        },
        (r) => {
          reject(r)
        }
      )
    }
  })
}
