# Promise的理解和使用
  # Promise是什么
    -理解
      - 抽象表达式
        1) Promise 是一门新的技术(ES6规范)
        2) Promise是js进行异步编程的解决方案
        备注:旧方案是单纯使用回调函数
      - 具体表达
        1) 从语法上来说:Promise 是一个构造函数
        2) 从功能上来说:promise对象用来封装一个异步操作并可以获取其成功/失败的结构值
  # 为什么要用Promise?
   - 指定的回调函数的方式更加灵活
     1 旧的:必须在启动异步任务前指定
     2 promise: 启动异步任务 => 返回promise对象=> 给promise对象绑定回调函数(甚至可以在异步任务结束后指定/多个)    
   - 支持链式调用,可以解决回调地狱问题
     1. 什么是回调地狱?
        回调函数嵌套调用,外部回调函数异步执行的结果是嵌套的回调执行的条件
     2. 回调地狱的缺点?
        不便于阅读
        不便于异步处理
     3. 解决方案
        Promise链式调用
     4.  
  # promise的状态改变
    1. pending变为resolved
    2. pending变为rejected
    说明:只有这2中,且promise对象只能改变一次,无论是否变为成功还是失败,都会有一个结果的数据(状态不可以改变)
    实例对象中的一个属性 PromiseState 
     * pending
     * resolved / fulfilled 成功
     * rejected 失败
  # promise 对象的值
    实例对象中的另外一个属性 [PromiseResult]  
    保存着对象[成功/失败]的结果 
    * resolve
    * reject
  # 如何使用promise
    * APi
      1. Promise构造函数:Promise(excutor){}
        - executor:执行器(resolve,reject)=>
        - resolve函数: 内部定义成功时我们调用的函数
        - reject函数:内部定义失败时我们调用的函数
        说明:excutor会在promis内部力即同步调用,异步操作在执行显示执行
      2. Promise.prototype.then 方法(onResolved,onResolved)=>{}
        - onResolved函数:成功的回调
        - onResolved函数:失败的回调
        说明:指定用于得到value的成功回调和利于得到失败reason的失败回调返回一个新的promise对象
      3. Promise.prototype.catch 方法(onReject)=>{}
        - onRejectd函数:失败的回调函数(reason)=>{}
      4. Promise.resolve方法(value)=>{}
        - value:成功的数据或promise对象
          说明返回一个成功/失败的promise
      5. promise.reject方法(reason)=>{}
        - reason:失败的原因
      6. Promise.all 方法(pending)=>{}
        - pending:包含n个promise的数组 
         说明返回一个新的prmise,只有所有的promise都成功才成功 只要有一个失败就直接失败了
      7. pending.race 方法(promises)=>{}
        - promise：包含n个promise的数组
          说明:返回一个新的promise,第一个完成的promise的结果状态就是最终的结果状态
    # promise的几个关键问题
      1. 如何改变promise的状态
         - resolve(value):如果当前是pending就会变成为resolved
         - reject(reason):如果当前是pending就会变为rejected
         - 抛出异常:如果当前是pending就会变为rejected
      2. 一个Promise 指定多个成功/失败回调函数，都会调用吗？
         - 当promise改变为对应的状态都会调用
      3. 改变promise状态和指定回调函数谁先谁后
         - 都有可能,正常情况下是先指定回调函数在改变状态,但也可以先改变状态在指定回调
         - 如果先改状态在执行回调
            - 在执行器中直接调用resolve()/reject()
            - 延迟更长时间才调用then()
         - 什么时候才能得到数据?
            - 如果先指定回调,那当状态发生改变时。回调函数就会调用，得到数据
            - 如果先改变状态，那当指定回调时 回调函数就会调用 得到数据
      4. promise.then 返回的新的promise 的结果状态由什么决定的?
          - 简单表达:由then()指定的回调函数执行的结果决定
          - 详细表达
             - 如果抛出异常,新promise变为reject,reason为抛出异常
             - 如果返回值的是非promise的任意值,新pronise变为resolved,value为返回值
             - 如果返回的是另一个新promise,此promise的结果就会成为promise的结果
      5. Promise如何串联多个操作任务
          - promise的then() 返回一个新的promise 可以开成then() 的链式调用
          - 通过then的链式调用串联多个同步/异步任务  
      6. promise异常穿透
          - 当使用promise的then 链式调用时,可以在最后指定失败的回调
          - 前面任何操作出了异常 都会传到最后失败的回调函数中处理
      7. 中断promise链
          - 当使用promise的then链式调用时，在中间中断不在调用后郁闷的回调函数
          - 方法:在回调函数中返回一个padding状态的promise对象         
# async与await
  * async 函数
    - 函数的返回值是一个promise对象
    - promise对象的结果由async函数执行的返回值决定
  * await 表达式
    - await右侧的表达式一般为promise对象 但也可以是其它的值
    - 如果表达式是promise对象,await返回值是promise的值
    - 如果表达式是其它值，直接将此值作为await的返回值
  * 注意
    - await必须写在async函数中,但async函数中可以没有await
    - 如果await的promise失败了 就会抛出异常 需要通过try catch捕获处理