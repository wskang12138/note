const fs = require('fs')
// 回调函数
// fs.readFile('./md.md', (err, data) => {
//   if (err) throw err
//   console.log(data.toString());
// })
// Promise 形式
// let p = new Promise((resolve, reject) => {
//   fs.readFile('./md.md', (err, data) => {
//     if (err) reject(err)
//     resolve(data)
//   })
// })
// p.then((res) => {
//   console.log(res.toString())
// }, (err) => {
//   console.log(err);
//  })

// 封装

function mineReadFile(path) {
  return new Promise((resolve, reject) => {
    fs.readFile(path, (err, data) => {
      if (err) reject(err)
      resolve(data)
    })
  })
}
mineReadFile('./md.md').then(
  (res) => {
    console.log(res.toString())
  },
  (err) => {
    console.log(err)
  }
)

// const util = require('util')
// const fs = require('fs')
// let mineReadFile2 = util.promiseify(fs.readFile) // 返回的是一个promise对象
// mineReadFile2('./md.md').then(
//   (res) => {
//     console.log(res.toString())
//   },
//   (err) => {
//     console.log(err)
//   }
// )

