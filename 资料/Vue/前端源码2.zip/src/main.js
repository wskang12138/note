import { createApp } from 'vue'
import App from './App.vue'
import css from './assets/css.css'
createApp(App).use(css).mount('#app')
