<template>
  <div class="mdui-drawer mdui-drawer-close" id="left-drawer">
    <ul class="mdui-list">
      <li class="mdui-subheader">导航</li>
      <li class="mdui-list-item mdui-ripple">
        <i class="mdui-list-item-icon mdui-icon material-icons">home</i>
        <div class="mdui-list-item-content">首页</div>
      </li>

      <li class="mdui-subheader">组成</li>
      <li class="mdui-collapse-item mdui-collapse-item-open">
        <div class="mdui-collapse-item-header mdui-list-item mdui-ripple" @click="showSubList">
          <i class="mdui-list-item-icon mdui-icon material-icons">widgets</i>
          <div class="mdui-list-item-content">分类</div>
          <i class="mdui-collapse-item-arrow mdui-icon material-icons">{{ subListIcon }}</i>
        </div>
        <ul v-if="ifShowSubList" class="mdui-collapse-item-body mdui-list mdui-list-dense ">
          <li class="mdui-list-item mdui-ripple">前沿数码资讯</li>
          <li class="mdui-list-item mdui-ripple">用机技巧分享</li>
          <li class="mdui-list-item mdui-ripple">手机刷机经验</li>
          <li class="mdui-list-item mdui-ripple">手机刷机工具</li>
          <li class="mdui-list-item mdui-ripple">刷机ROM资源</li>
        </ul>
      </li>
    </ul>
    <img src="../assets/logo.png" style="position:absolute;bottom:0;left:calc(50% - 75px);width:150px" />
  </div>
  <div class="mdui-dialog" id="videoDialog">
    <div class="video-wrapper">
      <video v-if="toggleVideo" id="video" muted loop autoplay controls>
        <source src='https://hh88ss.xyz/正面的.mp4' type="video/mp4">
      </video>
      <video v-else id="video" muted loop autoplay controls>
        <source src='https://hh88ss.xyz/反面的.mp4' type="video/mp4">
      </video>
    </div>
    <div class="mdui-dialog-actions">

      <button @click="toggleVideoHandler">
        <i class="mdui-icon material-icons">&#xe8d4;</i>
      </button>
      <button class="mdui-btn mdui-ripple" mdui-dialog-close>关闭</button>
    </div>
  </div>
  <div style="position:relative;width: 100%;">

    <div class="navbar">
      <div>
        <a target="_blank" class="mdui-btn" href="https://www.jlwz.cn/wapindex-1000-325.html">音乐</a>
        <a target="_blank" class="mdui-btn" href="https://ps.bmcx.com/">修图</a>
      </div>
      <div>
        <a style="float:left;margin-top: 17px;" target="_blank" class="mdui-btn"
          href="https://wall.alphacoders.com/">4K</a>
        <div style="float:left;" class="mini-program-code" @mouseover="showQrCode = true"
          @mouseleave="showQrCode = false">
          <img style="width: 30px;height: 30px;float: left;margin-left: 30px;margin-top: 20px;"
            src="https://api.iconify.design/ic:baseline-qr-code.svg?color=%23ffffff" />
        </div>
        <div class="menu-button" mdui-drawer="{target: '#left-drawer'}">
          <i class="mdui-icon material-icons">&#xe5d2;</i>
        </div>
      </div>
      <div style="position:absolute;top:90px;left:20px" v-if="showQrCode">
        <img style="width:150px;height:150px" src="../assets/28311668960060_.pic.jpg" />
      </div>
    </div>
    <div class="logo">
      <img src="../assets/logo.png" @click="showBack = !showBack" />
      <div v-if="showBack" class="showback operation backbtn">
        <button @click="showVideoWrapper = !showVideoWrapper">
          <i class="mdui-icon material-icons">keyboard_arrow_left</i>
        </button>
      </div>
      <div v-if="showBack" class="showback operation backlogo">
        <button mdui-dialog="{target: '#videoDialog'}">
          <img src="../assets/logo.png" />
        </button>
      </div>
    </div>

    <div class="form">
      <div class="input">
        <input id="input" v-model="inputVal" type="text" placeholder="请输入要解析的视频" ref="inputVal" />
        <a v-if="inputVal" class="paste-btn clear-btn" @click="this.inputVal = ''">
          <i class="mdui-icon material-icons">&#xe14c;</i>
        </a>
        <a class="paste-btn" @click="paste()">
          <i class="mdui-icon material-icons">&#xe14f;</i>
        </a>
      </div>
      <a class="get-video mdui-btn mdui-color-indigo mdui-btn-block mdui-ripple" @click="parseVideo()">{{ yjqc }}</a>
      <p id="plswait" style="font-weight: bold;padding-top: 20px;margin-bottom: 20px;color: #FFF">
        {{ plswait }}
      </p>
      <div id="plswaitTxt" style="display:none">{{ plswait }}</div>
    </div>

    <div class="announce">

      <a style="display: block;position: absolute;top: -30px;" @click="translate" href="javascript:;">
        <img style="width:40px;"
          src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBhcmlhLWhpZGRlbj0idHJ1ZSIgcm9sZT0iaW1nIiBjbGFzcz0iaWNvbmlmeSBpY29uaWZ5LS1tYXRlcmlhbC1zeW1ib2xzIiB3aWR0aD0iMWVtIiBoZWlnaHQ9IjFlbSIgcHJlc2VydmVBc3BlY3RSYXRpbz0ieE1pZFlNaWQgbWVldCIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBmaWxsPSIjZmZmZmZmIiBkPSJtMTIgMjJsLTEtM0g0cS0uODI1IDAtMS40MTItLjU4N1EyIDE3LjgyNSAyIDE3VjRxMC0uODI1LjU4OC0xLjQxM1EzLjE3NSAyIDQgMmg2bC44NzUgM0gyMHEuODc1IDAgMS40MzguNTYyUTIyIDYuMTI1IDIyIDd2MTNxMCAuODI1LS41NjIgMS40MTNRMjAuODc1IDIyIDIwIDIyWm0tNC44NS03LjRxMS43MjUgMCAyLjgzOC0xLjExMlExMS4xIDEyLjM3NSAxMS4xIDEwLjZxMC0uMi0uMDEyLS4zNjNxLS4wMTMtLjE2Mi0uMDYzLS4zMzdoLTMuOTV2MS41NUg5LjNxLS4yLjctLjc2MyAxLjA4N3EtLjU2Mi4zODgtMS4zNjIuMzg4cS0uOTc1IDAtMS42NzUtLjdxLS43LS43LS43LTEuNzI1cTAtMS4wMjUuNy0xLjcyNXEuNy0uNyAxLjY3NS0uN3EuNDUgMCAuODUuMTYycS40LjE2My43MjUuNDg4TDkuOTc1IDcuNTVROS40NSA3IDguNzEzIDYuN3EtLjczOC0uMy0xLjU2My0uM3EtMS42NzUgMC0yLjg2MiAxLjE4N1EzLjEgOC43NzUgMy4xIDEwLjVxMCAxLjcyNSAxLjE4OCAyLjkxMlE1LjQ3NSAxNC42IDcuMTUgMTQuNlptNi43LjVsLjU1LS41MjVxLS4zNS0uNDI1LS42MzctLjgyNXEtLjI4OC0uNC0uNTYzLS44NVptMS4yNS0xLjI3NXEuNy0uODI1IDEuMDYzLTEuNTc1cS4zNjItLjc1LjQ4Ny0xLjE3NWgtMy45NzVsLjMgMS4wNWgxcS4yLjM3NS40NzUuODEzcS4yNzUuNDM3LjY1Ljg4N1pNMTMgMjFoN3EuNDUgMCAuNzI1LS4yODhRMjEgMjAuNDI1IDIxIDIwVjdxMC0uNDUtLjI3NS0uNzI1UTIwLjQ1IDYgMjAgNmgtOC44MjVsMS4xNzUgNC4wNWgxLjk3NVY5aDEuMDI1djEuMDVIMTl2MS4wMjVoLTEuMjc1cS0uMjUuOTUtLjc1IDEuODVxLS41LjktMS4xNzUgMS42NzVsMi43MjUgMi42NzVMMTcuOCAxOGwtMi43LTIuN2wtLjkuOTI1TDE1IDE5WiI+PC9wYXRoPjwvc3ZnPg==" />
      </a>
      <img src="../assets/share.png" />
      <img src="../assets/share1.png" />
      <img src="../assets/share3.png" />
      <br />
      <br />
      {{ sharelink }}
      <a class="no-link-button" mdui-dialog="{target: '#noLinkButton'}">{{ nolinkbtn }}<br />
        （<i class="mdui-icon material-icons">&#xe90d;</i>{{ plsclick }}）
      </a>

      <div style="margin-top:10px;">
        <p style="font-weight:bold;">{{ iphoneuser }}</p>
        <p style="font-weight:normal;margin-top:10px;">{{ iphoneusertxt }}</p>
      </div>
    </div>
    <div class="mdui-dialog" id="noLinkButton">
      <div class="mdui-dialog-title">{{ nolinkbtn }}</div>
      <div class="mdui-dialog-content">
        {{ nolinkbtntxt }}
      </div>
      <div class="mdui-dialog-actions">
        <button class="mdui-btn mdui-ripple" mdui-dialog-confirm>OK</button>
      </div>
    </div>
    <div id="loadingDialog" v-if="ifShowLoading">
      <div class="loading-wrapper">
        <img class="loading-img" src="../assets/img_77412.png" />
        <div class="loading-title">{{ loadingTitle }}</div>
        <div style=""></div>
      </div>
    </div>
    <div class="saveDialog" v-if="ifShowSave">
      <div class="saveDialog-wrapper">
        <div>
          <video ref="videoPlay" style="width:200px" :src="noMarkVideo" controls :autoplay="1" id="playVideos">
          </video>
        </div>
        <div class="save-btn-group">
          <a class="save-btn mdui-btn mdui-color-indigo mdui-ripple" :href="noMarkVideo" download>{{ save }}</a>
          <a class="save-btn mdui-btn mdui-color-pink mdui-ripple" @click="this.ifShowSave = false">{{ close }}</a>
        </div>
        <div class="save-about">
          <p style="font-size: 17px;padding-bottom: 10px">{{ friendalert }}</p>
          {{ friendalerttxt }}
          <div>{{ friendalerttxt1 }}</div>
        </div>
      </div>
    </div>

  </div>
  <div class="right-video">

    <div v-if="showVideoWrapper">
      <div class="operation">
        <button @click="toggleVideoHandler">
          <i class="mdui-icon material-icons">&#xe8d4;</i>
        </button>
      </div>
      <div class="video-wrapper">
        <video v-if="toggleVideo" id="video" muted loop autoplay>
          <source src='https://hh88ss.xyz/正面的.mp4' type="video/mp4">
        </video>
        <video v-else id="video" muted loop autoplay style="margin-top:-200px;">
          <source src='https://hh88ss.xyz/反面的.mp4' type="video/mp4">
        </video>
      </div>
    </div>
  </div>
</template>
<script>
import CryptoJS from "crypto-js";
import API from "../utils/requests";
import qs from 'qs';
export default {
  data() {
    return {
      showVideoWrapper: true,
      showBack: false,
      toggleVideo: 'https://hh88ss.xyz/正面的.mp4',
      ifShowSave: false,
      ifShowLoading: false,
      inputVal: '',
      videoUrl: '',
      noMarkVideo: '',
      yjqc: '一键去除水印',
      flag: 0,
      plswait: '友情提示:解析正常，请耐心等待...',
      sharelink: '请在各渠道平台，选择如上图标按钮复制链接，粘贴到本站搜索框进行解析下载服务！',
      nolinkbtn: '没有分享链接按钮？',
      plsclick: '请手触或鼠标点击查看方法',
      iphoneuser: '苹果用户无法下载？',
      iphoneusertxt: '请在应用商店中下载Document软件，本站解析后的视频链接复制到Document的搜索框，即可完成下载',
      nolinkbtntxt: '请分享到QQ/微信，再复制链接到搜索框进行解析服务。',
      friendalert: '友情提示：',
      friendalerttxt: '短视频无水印解析小程序仅供技术交流请勿用于非法用途，下载后请二十四小时之内删除，版权仅归短视频官方所有。若侵犯了贵公司的权益。',
      friendalerttxt1: '请发邮件至：271098819@qq.com，我会在24小时内及时处理，谢谢合作！',
      save: '保存',
      close: '关闭',
      showQrCode: false,
      subListIcon: "keyboard_arrow_up",
      ifShowSubList: false,
    }
  },
  mounted() {
    this.login();
    this.paste();
    document.getElementById("video").play()
    var canvas = document.createElement("canvas");
    document.getElementsByTagName("body")[0].appendChild(canvas);
    var ctx = canvas.getContext("2d");

    var numParticles = 140;

    var bg = [2, 2, 2];
    var cols = [
      "#ff0000",
      "#ff0000",
      "#ff0000",
      "#ff0000",
      "#ff0000",
      "#ff9900",
      "#ffffff",
      "#990000",
    ];
    // var cols = ['#FF5722', '#FF9800', '#FF9800', '#FF9800', '#FF9800', '#B71C1C', '#00BCD4', '#00BCD4', '#009688']

    setup();
    window.addEventListener("resize", setup);

    function setup() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      ctx.beginPath();
      ctx.rect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = `rgba(${bg[0]}, ${bg[1]}, ${bg[2]}, ${1})`;
      ctx.fill();
    }

    var step = 0;

    var mouse = {
      x: canvas.width / 2,
      y: canvas.height / 2,
    };
    document.onmousemove = function (e) {
      mouse = { x: e.pageX, y: e.pageY };
    };

    setInterval(animate, 1000 / 30);
    // window.requestAnimationFrame(animate);
    function animate() {
      fade(0.34);
      draw();
      // window.requestAnimationFrame(function(){animate()})
    }

    function fade(amt) {
      ctx.beginPath();
      ctx.rect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = `rgba(${bg[0]}, ${bg[1]}, ${bg[2]}, ${amt})`;
      ctx.fill();
    }

    function Particle() {
      this.pos = {
        x: Math.random() * canvas.width * 0.1 + canvas.width * 0.45,
        y: Math.random() * canvas.height * 0.1 + canvas.height * 0.45,
      };
      this.r = 1;
      this.speed = 22;
      this.hue = [44, 36, 36, 24, 14, 4, 24, 24][
        Math.floor(Math.random() * 7)
      ];
      this.step = Math.random() * 400;
      this.vx = (Math.random() * this.speed) / 4 - this.speed / 8;
      this.vy = (Math.random() * this.speed) / 4 - this.speed / 8;
      this.colIndex = Math.floor(Math.random() * cols.length);
      this.history = [];
      this.update = function () {
        //////////////////////////////////////
        this.step++;
        this.step %= 400;
        if (this.history.length > 5) {
          this.history.shift();
        }
        this.pos.x += this.vx;
        this.pos.y += this.vy;
        this.vx =
          this.vx * 0.8 + (Math.random() * this.speed * 2 - this.speed) * 0.2;
        this.vy =
          this.vy * 0.8 + (Math.random() * this.speed * 2 - this.speed) * 0.2;

        // mouse dist
        // var dx = mouse.x - this.pos.x
        // var dy = mouse.y - this.pos.y
        if (this.step > 325 || (this.step > 100 && this.step < 190)) {
          var m = Math.min(canvas.height, canvas.width) * 0.3;
          var p = (Math.PI * 2 * (step + this.step * 0.01)) / 180;
          this.vx =
            (Math.cos(p) * m - this.pos.x + canvas.width / 2) * 0.016 +
            this.vx * 0.97;
          this.vy =
            (Math.sin(p) * m - this.pos.y + canvas.height / 2) * 0.016 +
            this.vy * 0.97;
          //mouse
          // this.vx = this.vx * 0.9 + dx * 0.02
          // this.vy = this.vy * 0.9 + dy * 0.02
          // this.vx = Math.min(this.vx,  4.0)
          // this.vx = Math.max(this.vx, -4.0)
          // this.vy = Math.min(this.vy,  4.0)
          // this.vy = Math.max(this.vy, -4.0)
          // center
          // this.vx = this.vx * 0.9 + (canvas.width/2 - this.pos.x ) * 0.002
          // this.vy = this.vy * 0.9 + (canvas.height/2 - this.pos.y ) * 0.002
        }

        //     if(this.step > 100 && this.step < 140) {
        //       //mouse
        //       var d = dx * dx + dy * dy
        //       if (d < (canvas.height/8 * canvas.height/8)){
        //         this.vx = this.vx * 0.9 - (mouse.x - this.pos.x ) * 0.01
        //         this.vy = this.vy * 0.9 - (mouse.y - this.pos.y ) * 0.01
        //       }
        //       // center
        //       // this.vx = this.vx * 0.9 + (canvas.width/2 - this.pos.x ) * 0.002
        //       // this.vy = this.vy * 0.9 + (canvas.height/2 - this.pos.y ) * 0.002
        //     }

        var speed = Math.min(Math.abs(this.vx) + Math.abs(this.vy), 50) / 50;
        //////////////////////////////////////
        if (this.history.length > 4) {
          ctx.beginPath();
          // ctx.arc(this.pos.x ,this.pos.y , this.r, 0, 2 * Math.PI)
          ctx.moveTo(this.pos.x, this.pos.y);
          for (var i = this.history.length - 1; i >= 0; i--) {
            ctx.lineTo(this.history[i].x, this.history[i].y);
          }
          ctx.fillStyle = `hsla(${this.hue},${99}%,${speed * 70 + 30}%,${speed * 0.3 + 0.7
            })`;
          // ctx.strokeStyle = `hsla(${Math.sin( this.step / 300) * 70 + 70},${99}%,${50}%,0.5)`
          // ctx.fillStyle = cols[this.colIndex]
          // ctx.strokeStyle = cols[this.colIndex]
          ctx.fill();
          ctx.lineWidth = 1;
          ctx.lineJoin = "round";
          // ctx.closePath()
          // ctx.stroke()
        }
        //////////////////////////////////////
        if (
          this.pos.x > canvas.width ||
          this.pos.x < 0 ||
          this.pos.y > canvas.height ||
          this.pos.y < 0
        ) {
          delete this.pos;
          delete this.history;
          return false;
        }
        this.history.push({
          x: this.pos.x,
          y: this.pos.y,
        });
        return true;
      };
    }

    var particles = [new Particle()];

    function draw() {
      step++;
      step %= 180;

      if (particles.length < numParticles) {
        particles.push(new Particle());
      }

      particles = particles.filter(function (p) {
        return p.update();
      });
    }
  },
  watch: {
    inputVal: {

    }
  },
  methods: {
    toggleVideoHandler() {
      this.toggleVideo = !this.toggleVideo
      console.log(this.toggleVideo);
    },
    showSubList() {
      if (this.ifShowSubList) {
        this.subListIcon = "keyboard_arrow_up"
      } else {
        this.subListIcon = "keyboard_arrow_down"
      }
      this.ifShowSubList = !this.ifShowSubList;
    },
    getQrCode() {
      this.showQrCode = true
    },
    translate() {
      if (this.flag) {
        this.plswait = '友情提示:解析正常，请耐心等待...'
        this.sharelink = '请在各渠道平台，选择如上图标按钮复制链接，粘贴到本站搜索框进行解析下载服务！'
        this.nolinkbtn = '没有分享链接按钮？'
        this.plsclick = '请手触或鼠标点击查看方法'
        this.iphoneuser = '苹果用户无法下载？'
        this.iphoneusertxt = '请在应用商店中下载Document软件，本站解析后的视频链接复制到Document的搜索框，即可完成下载'
        this.nolinkbtntxt = '请分享到QQ/微信，再复制链接到搜索框进行解析服务。'
        this.friendalert = '友情提示：'
        this.friendalerttxt = '短视频无水印解析小程序仅供技术交流请勿用于非法用途，下载后请二十四小时之内删除，版权仅归短视频官方所有。若侵犯了贵公司的权益。'
        this.friendalerttxt1 = '请发邮件至：271098819@qq.com，我会在24小时内及时处理，谢谢合作！'
        this.save = '保存'
        this.close = '关闭'

      } else {
        this.plswait = 'Welcome,Our Service is running now.Please wait patiently.'
        this.sharelink = 'Please select the icon button above to copy the link on each channel platform, and paste it into the search box of this site for analysis and download service!'
        this.nolinkbtn = 'No Share Button?'
        this.plsclick = 'Click Me'
        this.iphoneuser = "I am an iPhone user,Can't Download"
        this.iphoneusertxt = 'Go to APPSTORE and Install "Document",then paste the video url into Document APP.'
        this.nolinkbtntxt = 'Please share the video to QQ/Wechat,then copy the video link to our site.'
        this.friendalert = 'Friendly Notice：'
        this.friendalerttxt = 'The short video no watermark parsing applet is for technical exchange only, please do not use it for illegal purposes, please delete it within 24 hours after downloading, and the copyright is only owned by the short video official. If the rights of your company are violated.'
        this.friendalerttxt1 = 'Please send EMail to：271098819@qq.com，I will solve in 24H,Thanks for understand.'
        this.save = 'Save'
        this.close = 'Close'
      }
      this.flag = !this.flag
    },
    login() {
      let uid = 'bochi' + this.generateRamStr(10) + 'li';
      uid = this.encrypt(uid);
      API.post("/users/api/getToken", qs.stringify({ uid })).then(res => {
        console.log(res)
        sessionStorage.setItem("token", res.data.data.token)
      })
    },
    generateRamStr(len, charSet) {
      const chars = charSet || "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
      let randomStr = "";
      for (var i = 0; i < len; i++) {
        randomStr += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return randomStr;
    },
    encrypt(word, keyStr, ivStr) {
      keyStr = keyStr ? keyStr : "absoietlj32fai12";
      ivStr = ivStr ? ivStr : "absoietlj32fai12";
      let key = CryptoJS.enc.Utf8.parse(keyStr);
      let iv = CryptoJS.enc.Utf8.parse(ivStr);
      let srcs = CryptoJS.enc.Utf8.parse(word);

      let encrypted = CryptoJS.AES.encrypt(srcs, key, {
        iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.ZeroPadding
      });
      return encrypted.toString();
    },
    // 解密
    decrypt(word, keyStr, ivStr) {
      keyStr = keyStr ? keyStr : "absoietlj32fai12";
      ivStr = ivStr ? ivStr : "absoietlj32fai12";
      var key = CryptoJS.enc.Utf8.parse(keyStr);
      let iv = CryptoJS.enc.Utf8.parse(ivStr);

      var decrypt = CryptoJS.AES.decrypt(word, key, {
        iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.ZeroPadding
      });
      return decrypt.toString(CryptoJS.enc.Utf8);
    },
    inputEvent(e) {
      console.log(e)
    },
    replaceReg(t) {
      var that = this
      var a = /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/g;
      return t.replace(a, function (t) {
        that.videoUrl = t;
      });
    },
    regUrl(t) {
      return /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/.test(
        t
      );
    },
    showLoading(text) {
      this.ifShowLoading = true;
      this.loadingTitle = text;
    },
    hideLoading() {
      this.ifShowLoading = false;
    },
    showToast(text) {
      mdui.snackbar({
        message: text,
        position: "bottom",
      });
    },
    paste() {
      navigator.permissions
        .query({
          name: "clipboard-read",
        })
        .then((result) => {
          if (result.state === "granted" || result.state === "prompt") {
            navigator.clipboard.readText().then((text) => {
              this.inputVal = text;
            });
          } else {
            alert("请允许读取剪贴板！");
          }
        });
    },
    parseVideo() {
      this.replaceReg(this.inputVal), "" !== this.inputVal && this.regUrl(this.inputVal)
        ? (this.showLoading("正在启动中..."), this.getVideo())
        : this.showToast("请复制视频链接");
    },
    showSaveDialog() {
      this.ifShowSave = true;
    },
    getVideo() {
      var that = this;
      console.log(this.videoUrl)
      let form = {
        url: that.videoUrl
      }
      API.post("/users/api/getVideo", qs.stringify(form)).then(res => {
        if (!res.data.error && res.data.data.code === 200) {
          if (res.data.data.url.search("ixigua") !== -1) {
            that.noMarkVideo = res.data.data.url + ".MP4";
            that.showSaveDialog()
            that.hideLoading()
          } else {
            that.noMarkVideo = res.data.data.url;
            that.showSaveDialog()
            that.hideLoading()
          }
        } else {
          that.hideLoading()
          that.showLoading("解析失败！")
          setTimeout(that.hideLoading, 1000)
        }
      })

    },
    saveVideo() {

    },
  },

}
</script>
<style scoped>
a {
  /*color: #42b983;*/
}

.showback {
  position: absolute;
  z-index: 9999;
  top: 250px;
  right: -100px;
}

.menu-button {
  color: gainsboro;
  float: left;
  position: relative;
  left: 25px;
}

.menu-button:hover {
  cursor: pointer;
}

.mdui-drawer {
  background: rgba(173, 173, 173, .27);
  color: #fff !important;
  text-align: left;
}

.mdui-drawer .mdui-subheader {
  color: #fff !important;
}

.mdui-drawer .mdui-list-item-icon {
  color: #fff !important;

}

.right-video {
  position: absolute;
  right: 20px;
  top: 250px;
}

.video-wrapper {
  /* border: 1px solid #ddd; */
  float: right;
}

.operation {
  float: left;
  color: #FFF;
  display: flex;
  width: 100px;
  flex-direction: column;
  flex-wrap: nowrap;
  align-items: center;
  height: 250px;
  justify-content: center;
}

.operation button {
  flex: 1;
  color: #FFF;
  background: rgba(0, 0, 0, 0);
  outline: none;
  border: none;
  height: 50px;
  width: 100%;
  text-align: center;
  cursor: pointer;
}

.operation .mdui-icon {
  font-size: 50px;
}


video {
  mix-blend-mode: screen;
}

.backlogo {
  display: none;
}

.mdui-dialog {
  z-index: 99999;
  height: none;
}

.mdui-dialog .operation button {
  color: #fff;
}

@media screen and (max-width:1365px) {
  .right-video {
    display: none;
  }

  .backbtn {
    display: none;
  }

  .backlogo {
    display: block;
    right: -20px;
    top: 340px;
    height: 50px;
  }

  .backlogo img {
    width: 50px;
  }

  button {
    color: #000;
    background: rgba(0, 0, 0, 0);
    outline: none;
    border: none;
    text-align: center;
    cursor: pointer;
  }

  .video-wrapper {
    float: none;
  }

  video {
    margin: 0 !important;
    mix-blend-mode: normal;
    width: 100%;
    height: 100%;
    max-height: 350px;
  }
}
</style>
